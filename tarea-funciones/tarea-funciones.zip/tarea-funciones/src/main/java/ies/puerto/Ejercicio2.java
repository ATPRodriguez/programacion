package ies.puerto;

public class Ejercicio2 {
    /**
     * Ejercicio que calcula el area de un circulo
     * @param radio del circulo
     * @return area del circulo
     */
    public double areaCirculo(int radio) {
        double resultado = 0;
        resultado = (radio*radio)*Math.PI;
        return resultado;
    }
}