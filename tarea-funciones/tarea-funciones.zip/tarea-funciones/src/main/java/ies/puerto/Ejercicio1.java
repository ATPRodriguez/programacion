package ies.puerto;

public class Ejercicio1 {
    /**
     * Ejercicio que calcula el area de un triangulo
     * @param base del triangulo
     * @param altura del triangulo
     * @return area del triangulo
     */
    public int areaTriangulo(int base, int altura) {
        int resultado = 0;
        resultado = (base*altura)/2;
        return resultado;
    }

}